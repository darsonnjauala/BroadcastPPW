let numero1 = document.querySelector('numero1');
let numero2 = document.querySelector('numero2');

function tim() {
    return numero1 * numero2;
}

function add() {
    return numero1 + numero2;
}

function sub() {
    return numero1 - numero2;
}

function div() {
    return numero1 / numero2;
}

let resultado = document.querySelector("resultado");